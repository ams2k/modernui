program exemplo_modernui;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  {$IFDEF HASAMIGA}
  athreads,
  {$ENDIF}
  Interfaces, // this includes the LCL widgetset
  Forms, zcomponent, View.Main, View.ControleUsuarios, View.MessageQuery,
  Util.EasyThead, Util.Imagem, Util.MessagePopup, Util.ValidacaoCampos,
  Service.Usuario, Usuario.Database
  { you can add units after this };

{$R *.res}

begin
  RequireDerivedFormResource := True;
  Application.Scaled := True;
  {$PUSH}{$WARN 5044 OFF}
  Application.MainFormOnTaskbar := True;
  {$POP}
  Application.Initialize;
  Application.CreateForm(TfrmViewMain, frmViewMain);
  Application.CreateForm(TfrmControleUsuarios, frmControleUsuarios);
  Application.CreateForm(TMessageQuery, MessageQuery);
  Application.Run;
end.

