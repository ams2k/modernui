unit View.Main;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ActnList,
  Menus, EditPlus, SplitViewUI, SplitViewButton, LabelPlus, ButtonRetro,
  CheckBoxPlus, ToggleButtonPlus, ChasePanel, CircularProgressBar, PanelPlus,
  MaskedEditPlus, ButtonPlus;

type

  { TfrmViewMain }

  TfrmViewMain = class(TForm)
    Action1: TAction;
    Action2: TAction;
    Action3: TAction;
    ActionList1: TActionList;
    Button1: TButton;
    ButtonPlus1: TButtonPlus;
    ButtonRetro1: TButtonRetro;
    ChasePanel1: TChasePanel;
    CheckboxPlus1: TCheckboxPlus;
    EditPlus1: TEditPlus;
    ImageList1: TImageList;
    imgMenuItens: TImageList;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    lblValor: TLabel;
    LabelPlus1: TLabelPlus;
    LabelPlus2: TLabelPlus;
    edtValor: TMaskedEditPlus;
    edtTelefone: TMaskedEditPlus;
    edtCpfCnpj: TMaskedEditPlus;
    SplitViewButton1: TSplitViewButton;
    SplitViewButton10: TSplitViewButton;
    SplitViewButton11: TSplitViewButton;
    SplitViewButton12: TSplitViewButton;
    SplitViewButton13: TSplitViewButton;
    SplitViewButton14: TSplitViewButton;
    SplitViewButton15: TSplitViewButton;
    SplitViewButton16: TSplitViewButton;
    SplitViewButton17: TSplitViewButton;
    SplitViewButton18: TSplitViewButton;
    SplitViewButton2: TSplitViewButton;
    SplitViewButton3: TSplitViewButton;
    SplitViewButton4: TSplitViewButton;
    SplitViewButton5: TSplitViewButton;
    SplitViewButton6: TSplitViewButton;
    SplitViewButton7: TSplitViewButton;
    SplitViewButton8: TSplitViewButton;
    SplitViewButton9: TSplitViewButton;
    SplitViewUI1: TSplitViewUI;
    SplitViewUI2: TSplitViewUI;
    SplitViewUI3: TSplitViewUI;
    SplitViewUI4: TSplitViewUI;
    SplitViewUI5: TSplitViewUI;
    svuMenu1: TSplitViewUI;
    svuMenu2: TSplitViewUI;
    svuMenu3: TSplitViewUI;
    ToggleButtonPlus1: TToggleButtonPlus;
    procedure Action1Execute(Sender: TObject);
    procedure Action2Execute(Sender: TObject);
    procedure Action3Execute(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure ButtonRetro1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure LabelPlus1Click(Sender: TObject);
    procedure edtValorExit(Sender: TObject);
    procedure SplitViewButton11Click(Sender: TObject);
    procedure SplitViewButton12Click(Sender: TObject);
    procedure SplitViewButton13Click(Sender: TObject);
    procedure SplitViewButton16Click(Sender: TObject);
    procedure SplitViewButton1Click(Sender: TObject);
    procedure SplitViewButton4Click(Sender: TObject);
    procedure SplitViewButton7Click(Sender: TObject);
    procedure SplitViewUI1Click(Sender: TObject);
    procedure SplitViewUI4Click(Sender: TObject);
    procedure svuMenu1Click(Sender: TObject);
  private

  public

  end;

var
  frmViewMain: TfrmViewMain;

implementation

uses
  View.ControleUsuarios;

{$R *.lfm}

{ TfrmViewMain }

procedure TfrmViewMain.FormShow(Sender: TObject);
begin
  with DefaultFormatSettings do begin
    CurrencyString := 'R$';
    CurrencyFormat := 2;
    DecimalSeparator := ',';
    ThousandSeparator := '.';
    DateSeparator := '/';
    ShortDateFormat := 'dd/mm/yyyy';
  end;

  SplitViewUI5.Opened := False;

  ChasePanel1.Start;

  edtTelefone.Text := '17980390564';
  edtValor.CurrencyValue := 1317.99;
end;

procedure TfrmViewMain.LabelPlus1Click(Sender: TObject);
begin
  ShowMessage('Label');
end;

procedure TfrmViewMain.edtValorExit(Sender: TObject);
begin
  lblValor.Caption := 'VALOR * 2 = %0.2f'.Format([edtValor.CurrencyValue * 2]);
end;

procedure TfrmViewMain.SplitViewButton11Click(Sender: TObject);
begin
  SplitViewUI4.Visible := False;
end;

procedure TfrmViewMain.SplitViewButton12Click(Sender: TObject);
begin
  SplitViewUI4.Visible := not SplitViewUI4.Visible;
end;

procedure TfrmViewMain.SplitViewButton13Click(Sender: TObject);
begin
  SplitViewUI4.Visible := False;
  ShowMessage(TSplitViewButton(Sender).Name);
end;

procedure TfrmViewMain.SplitViewButton16Click(Sender: TObject);
begin
  SplitViewUI5.Opened := False;
  ShowMessage(TSplitViewButton(Sender).Name);
end;

procedure TfrmViewMain.SplitViewButton1Click(Sender: TObject);
begin
  if not SplitViewUI1.Opened then
    SplitViewUI1.Opened := True;
end;

procedure TfrmViewMain.SplitViewButton4Click(Sender: TObject);
begin
  ShowMessage('Botao 4');
end;

procedure TfrmViewMain.SplitViewButton7Click(Sender: TObject);
begin
  SplitViewUI5.Opened := not SplitViewUI5.Opened;
end;

procedure TfrmViewMain.SplitViewUI1Click(Sender: TObject);
begin
  //ShowMessage('Click no Menu');
end;

procedure TfrmViewMain.SplitViewUI4Click(Sender: TObject);
begin
  SplitViewUI5.Opened := False;
end;

procedure TfrmViewMain.svuMenu1Click(Sender: TObject);
var
  i: Integer;
begin
  SplitViewUI4.Visible := False;

  for i := 0 to ComponentCount -1 do begin
    if Components[i] is TSplitViewUI then begin
      if (TSplitViewUI(Components[i]).Tag = 9) and
         (TSplitViewUI(Components[i]).Opened) and
         (TSplitViewUI(Components[i]).Name <> TSplitViewUI(Sender).Name) then
        TSplitViewUI(Components[i]).Opened := False;
    end;
  end;
end;

procedure TfrmViewMain.Action1Execute(Sender: TObject);
begin
  ShowMessage('Action 1');
end;

procedure TfrmViewMain.Action2Execute(Sender: TObject);
begin
  ShowMessage('Action 2');
end;

procedure TfrmViewMain.Action3Execute(Sender: TObject);
begin
  ShowMessage('Action 3');
end;

procedure TfrmViewMain.Button1Click(Sender: TObject);
// acessar a grid
var
  f: TfrmControleUsuarios;
begin
  f := TfrmControleUsuarios.Create(self);
  f.ShowModal;
  FreeAndNil(f);
end;

procedure TfrmViewMain.ButtonRetro1Click(Sender: TObject);
begin
  ShowMessage('botão retrô');
end;

end.

